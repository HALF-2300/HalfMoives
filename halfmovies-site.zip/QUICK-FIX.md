# Quick Fix: Movies Not Appearing

## المشكلة
الأفلام الجديدة (حتى التي لديها روابط YouTube) لا تظهر في الموقع.

## الحل السريع

### 1. ارفع صفحة التشخيص
ارفع `debug-movies-display.html` إلى الخادم وافتحها:
- `https://yourdomain.com/debug-movies-display.html`
- ستظهر لك جميع الأفلام الجديدة ومعلوماتها

### 2. تحقق من الملف
افتح مباشرة: `https://yourdomain.com/movies.json`
- يجب أن ترى محتوى JSON
- يجب أن يكون الحجم ~116 KB
- يجب أن يحتوي على 120 فيلم

### 3. امسح الكاش
- اضغط `Ctrl + Shift + Delete`
- اختر "Cached images and files"
- اضغط "Clear data"
- Hard Refresh: `Ctrl + F5`

### 4. تحقق من Console
- افتح الموقع
- اضغط `F12` → Console
- ابحث عن أخطاء (أحمر)
- ابحث عن رسالة "Loaded X movies"

## إذا لم تظهر الأفلام بعد

### تحقق من:
1. ✅ `movies.json` في نفس مجلد `index.html`
2. ✅ اسم الملف: `movies.json` (حروف صغيرة)
3. ✅ حجم الملف: ~116 KB
4. ✅ عدد الأفلام: 120

### جرب:
1. احذف `movies.json` القديم
2. ارفع `movies.json` الجديد
3. امسح الكاش
4. Hard Refresh

## صفحة الاختبار
ارفع `debug-movies-display.html` وافتحها - ستخبرك بالضبط ما المشكلة!

